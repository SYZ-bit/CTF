# Workout

## Usage

```bash
./build.sh
./run.sh
nc 0 9999
```
