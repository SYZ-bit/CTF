#!/bin/sh

docker rm -f protocol
docker rmi -f protocol

docker build -t protocol .