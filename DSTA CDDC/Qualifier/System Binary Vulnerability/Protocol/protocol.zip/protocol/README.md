# protocol

```
./build.sh
./run.sh
nc localhost 11111
```