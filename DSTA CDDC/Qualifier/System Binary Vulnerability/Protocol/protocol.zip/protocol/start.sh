#!/bin/bash

nsjail -Ml --port 11111 --user 9999 --group 9999 --time_limit 30 --chroot /jail -- protocol