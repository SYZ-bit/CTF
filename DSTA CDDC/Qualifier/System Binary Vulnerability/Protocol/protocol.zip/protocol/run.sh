#!/bin/bash

docker rm -f protocol
docker run -d -p 11111:11111 --name protocol --restart unless-stopped --privileged protocol